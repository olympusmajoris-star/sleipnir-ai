"""Extend an existing SKU-aware native GroceryAisle with store-scoped inventory and bay geometry."""
from pathlib import Path

def apply(source):
    def edit(before,after):
        nonlocal source
        if source.count(before)!=1:
            raise ValueError(f'Unexpected widget revision near {before[:70]}')
        source=source.replace(before,after)

    edit('const double _gaMinScale = .5, _gaMaxScale = 1.5;',
         'const bool _gaAllStoreCatalogAisles = true;\nconst double _gaMinScale = .10, _gaMaxScale = 4.0;')
    edit('bool get _canSizeStock => _isTargetStore || _publixAisle;',
         'bool get _canSizeStock => _gaAllStoreCatalogAisles && widget.storeId.trim().isNotEmpty;')
    edit('if(!_publixAisle)return normal;','if(!_canSizeStock)return normal;')
    edit('''      if(_publixAisle)
        for(final item in _all.skip(first*_perPanel).take(math.max(0,end-first)*_perPanel))item.id,''',
         '''      if(!_isTargetStore)
        for(var p=first;p<end;p++)
          for(final item in _all.skip(_firstProductAtPanel(p)).take(
              _firstProductAtPanel(p+1)-_firstProductAtPanel(p))) item.id,''')
    edit('''    if ((!_gaAisles.containsKey(aisle) &&
            !_isTargetStore &&
            !_isDollarGeneral &&
            !_isAldi) ||
        aisle.isEmpty ||
        store.isEmpty)''',
         '''    if (aisle.isEmpty || store.isEmpty)''')
    edit('''    if (aisle == _cat ||
        (!_gaAisles.containsKey(aisle) &&
            !_isTargetStore &&
            !_isDollarGeneral &&
            !_isAldi)) return;''',
         '''    if (aisle.isEmpty || aisle == _cat) return;''')
    edit('''        return _isDollarGeneral || _isTargetStore
            ? _stockedAislePanel(p, near, const _GAAisleSpec(2, 2))
            : SizedBox(width: _panelW, height: _panelH);''',
         '''        return _stockedAislePanel(p, near, const _GAAisleSpec(2, 2));''')
    edit("        } else if (aisle == 'Bread & Rolls' && !_isDollarGeneral) {",
         "        } else if (aisle == 'Bread & Rolls' && !_isDollarGeneral && (_studio==null || _publixAisle)) {")
    edit('''        }else if(_publixAisle){
          final spec=_gaAisles[_cat];
          if(spec!=null){
            final i=index%_perPanel, row=i~/spec.columns, cellW=1.0/spec.columns;
            final dry=_cat=='Dry Goods & Pasta', canned=_cat=='Canned Goods & Soups'||_cat=='Condiments & Sauces';''',
         '''        }else{
          final panel=_panelForProductIndex(index);
          if(_isAldi && panel<_aldiRenders.length){
            final render=_aldiRenders[panel];
            panelNumber=render.number;
            slotNumber=render.slots.firstWhere((s)=>s.productId==item.id).slot;
          } else {
            final legacy=!_isDollarGeneral && !_isAldi;
            final spec=(legacy ? _gaAisles[_cat] : null) ?? const _GAAisleSpec(2,2);
            final i=index-_firstProductAtPanel(panel), row=i~/spec.columns, cellW=1.0/spec.columns;
            final dry=legacy && _cat=='Dry Goods & Pasta';
            final canned=legacy && (_cat=='Canned Goods & Soups'||_cat=='Condiments & Sauces');''')
    edit('''    final current=_byId[item.id] ?? item;''',
         '''    final current=_byId[item.id] ?? item;
    if(shelf==null && current.img.isEmpty && current.photoAlternates.isEmpty) {
      editable=false;maxScale=1;
    }''')
    edit('''          onAdd: _add);''',
         '''          onAdd: _studio?.onSelect==null ? _add : (item){unawaited(_selectForStudio(item));});''')
    edit('''    if (_isTargetStore) {
      final term = q.toLowerCase();''','''    if (_isTargetStore || _studio?.onSelect!=null) {
      final term = q.toLowerCase();''')
    # Preserve the original direct shopper path; editor search resolves the mounted SKU.
    edit('''      _panToContentX(_panelStartX(_panelForProductIndex(idx)));
    } else {
      _add(r);''','''      _panToContentX(_panelStartX(_panelForProductIndex(idx)));
      if(_studio?.onSelect!=null) unawaited(_selectForStudio(_all[idx]));
    } else if (_studio?.onSelect==null) {
      _add(r);''')
    edit('      : _gaAisles.keys;', '      : (_targetCategories.isNotEmpty ? _targetCategories : <String>{..._gaAisles.keys,_cat});')
    edit('      if (_isTargetStore && _targetCategories.isEmpty) {', """      if(_studio!=null && !_isTargetStore && _targetCategories.isEmpty) {
        Future<void> readCategories() async {
          try {
            final rows=await SupaFlow.client.rpc('studio_product_categories',params:{'p_store_id':store})
                .timeout(const Duration(seconds:12));
            if(!mounted || generation!=_loadGeneration || widget.storeId.trim()!=store) return;
            final names=<String>{aisle};
            for(final row in rows) {
              if(row['category'] is String && row['category'].trim().isNotEmpty &&
                  (num.tryParse('${row['product_count']}') ?? 0)>0) names.add(row['category'].trim());
            }
            setState(()=>_targetCategories=names.toList()..sort());
          } catch (_) { /* The scoped aisle inventory loads independently of its menu. */ }
        }
        unawaited(readCategories());
      }
      if (_isTargetStore && _targetCategories.isEmpty) {""")
    edit("                if (_isTargetStore)\n                  PopupMenuButton<String>(", "                if (_isTargetStore || _studio!=null)\n                  PopupMenuButton<String>(")
    return source

if __name__=='__main__':
    base=Path(__file__).resolve().parent
    (base/'GroceryAisle_AllStores_Studio.dart').write_text(apply((base/'GroceryAisle_Target_Studio.dart').read_text()))
