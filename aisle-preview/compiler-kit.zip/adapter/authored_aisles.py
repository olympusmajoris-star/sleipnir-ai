"""Integrate store-scoped authored displays in the existing shopper and preview."""
from pathlib import Path

ROOT = Path(__file__).resolve().parent

def apply(source):
    if 'class _GAAuthoredSurface ' in source:
        return source
    def change(before, after):
        nonlocal source
        if source.count(before)!=1:raise ValueError('Unsupported source near '+before[:75])
        source=source.replace(before,after)
    change('    this.dollarGeneral = false,','    this.dollarGeneral = false,\n    this.studioDraft, this.onAuthoredStatus,')
    change('  final bool dollarGeneral;','  final bool dollarGeneral;\n  final Map<String,dynamic>? studioDraft;\n  final ValueChanged<Map<String,dynamic>>? onAuthoredStatus;')
    change('  GroceryAisleStudioScope? _studio;', '''  GroceryAisleStudioScope? _studio;
  final _authoredKey=GlobalKey<_GAAuthoredSurfaceState>();
  bool get _authored => _gaAuthoredRoute(_cat);
  bool get _liveQuotes => _authored || _isTargetStore;
  Set<String> _authoredVisible={};
  void _acceptAuthored(String title,List<_GAItem> found) {
    _authoredVisible={for(final p in found)p.id};
    for(final item in found){_byId[item.id]=item;}
    _all=found;
    if(found.isNotEmpty)unawaited(_refreshScaleIds(_authoredVisible));
  }
  void _openAuthored(_GAItem item,int panel,int slot,double limit,String title,String aisleId){
    final selected=_studio?.onSelect;
    if(selected!=null){
      final editable=item.img.isNotEmpty;
      selected({'store_id':widget.storeId,'product_id':item.id,'name':item.name,'price':item.price.isFinite?item.price:null,
        'size':item.digitalSize,'image_url':item.img,'aisle':title,'aisle_id':aisleId,'page':panel,'slot':slot,
        'scale':_gaScale(_studio?.scales[item.id]??_savedScales[item.id],limit),'min_scale':editable?_gaMinScale:1.0,
        'max_scale':editable?limit:1.0,'editable':editable});
    }else{unawaited(_openProduct(item));}
  }
''')
    change('  void _measureShelf() {\n    if','  void _measureShelf() {\n    if(_authored)return;\n    if')
    change('    final generation = ++_loadGeneration;','    final generation = ++_loadGeneration;\n    if (_authored) { _loading=false; return; }')
    change('  Future<void> _refreshTargetPrices() async {','  Future<void> _refreshTargetPrices() async {\n    if(_authored)return;')
    change('    _armDigital();\n    if (_isTargetStore','    _armDigital();\n    if(_authored)return;\n    if (_isTargetStore')
    change('  bool get _usesTargetFixtures => _isTargetStore && !_usesPublishedTargetShelves;','  bool get _usesTargetFixtures => !_authored && _isTargetStore && !_usesPublishedTargetShelves;')
    change('    final ids = <String>{\n      if (_usesPublishedTargetShelves)','    final ids = <String>{\n      if (_authored) ..._authoredVisible,\n      if (_usesPublishedTargetShelves)')
    change('      if(!_isTargetStore)\n        for(var p=first;', '      if(!_isTargetStore && !_authored)\n        for(var p=first;')
    change('if(_isTargetStore && !scalesOnly)unawaited','if(_liveQuotes && !scalesOnly)unawaited')
    change('    if (!mounted || !_isTargetStore) return;\n    final pending', '    if (!mounted || !_liveQuotes) return;\n    final pending')
    change(".eq('store_id',_targetStoreId).inFilter('id',ids).timeout(const Duration(seconds:8))", ".eq('store_id',widget.storeId.trim()).inFilter('id',ids).timeout(const Duration(seconds:8))")
    change('session != _digitalSession || !_isTargetStore','session != _digitalSession || !_liveQuotes')
    change('    final digital = _isTargetStore;', '    final digital = _liveQuotes;')
    change('    if (_isTargetStore && d>0)', '    if (_liveQuotes && d>0)')
    change('    if (_isTargetStore && (!item.price.isFinite || item.price<=0)) {','    if (_liveQuotes && (!item.price.isFinite || item.price<=0)) {')
    change('if (_isTargetStore && _byId.containsKey(id)) continue;', 'if (_liveQuotes && _byId.containsKey(id)) continue;')
    change("final unknown=_isTargetStore && row['price_unavailable']==true;", "final unknown=_liveQuotes && row['price_unavailable']==true;")
    change("onTap: _isTargetStore && !_cartTotal.isFinite ? null", "onTap: _liveQuotes && !_cartTotal.isFinite ? null")
    change('    return LayoutBuilder(\n      builder: (context, constraints) {\n        final screen', '''    if(_authored) return _GAAuthoredSurface(key:_authoredKey,store:widget.storeId.trim(),route:_cat,
      draft:widget.studioDraft,onStatus:widget.onAuthoredStatus,onHydrated:_acceptAuthored,onItem:_openAuthored,
      live:(id)=>_byId[id],scales:{..._savedScales,...?_studio?.scales},cart:_cartArea,
      onBack:Navigator.canPop(context)?()=>Navigator.of(context).maybePop():null);
    return LayoutBuilder(
      builder: (context, constraints) {
        final screen''')
    change('  const _GADigitalTicket({super.key,required this.item,required this.scale});','  const _GADigitalTicket({super.key,required this.item,required this.scale,this.paper,this.ink});\n  final Color? paper,ink;')
    change("final small=TextStyle(inherit:false,color:const Color(0xff141a14)", "final small=TextStyle(inherit:false,color:ink??const Color(0xff141a14)")
    change("decoration:BoxDecoration(color:const Color(0xffe8eddf),","decoration:BoxDecoration(color:paper??const Color(0xffe8eddf),")
    change("style:TextStyle(inherit:false,color:const Color(0xff111810)","style:TextStyle(inherit:false,color:ink??const Color(0xff111810)")
    change('    final small=TextStyle(inherit:false,color:ink??const Color(0xff141a14)', '''    final appearance=_GAAuthoredAppearance.of(context);
    final ticketPaper=paper??_gaAuthoredColor(appearance['ticket_color']);
    final ticketInk=ink??_gaAuthoredColor(appearance['ticket_ink']);
    final small=TextStyle(inherit:false,color:ticketInk??const Color(0xff141a14)''')
    change('decoration:BoxDecoration(color:paper??const Color(0xffe8eddf)', 'decoration:BoxDecoration(color:ticketPaper??const Color(0xffe8eddf)')
    change('style:TextStyle(inherit:false,color:ink??const Color(0xff111810)', 'style:TextStyle(inherit:false,color:ticketInk??const Color(0xff111810)')
    change('    // One dynamic price string:', '''    final appearance=_GAAuthoredAppearance.of(context);
    final ticketPaper=_gaAuthoredColor(appearance['ticket_color']);
    final ticketInk=_gaAuthoredColor(appearance['ticket_ink']);
    // One dynamic price string:''')
    change('                  child: CustomPaint(painter: _GAPriceHolderFramePainter()),\n                ),',
           '''                  child: CustomPaint(painter: _GAPriceHolderFramePainter()),
                ),
                if(ticketPaper!=null)Positioned(left:width*.060,right:width*.060,top:height*.13,bottom:height*.11,
                  child:ColoredBox(color:ticketPaper)),''')
    change('color: const Color(0xFF080808),','color: ticketInk??const Color(0xFF080808),')
    return source+'\n'+(ROOT/'authored.part').read_text()+'\n'+(ROOT/'plates.part').read_text()

if __name__=='__main__':
 import sys
 Path(sys.argv[2]).write_text(apply(Path(sys.argv[1]).read_text()))
