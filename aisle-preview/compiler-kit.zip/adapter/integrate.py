"""Apply the Studio scope and physical per-product scale renderer to Target GroceryAisle."""
from pathlib import Path
HERE=Path(__file__).resolve().parent

def apply(source_text):
    s=source_text
    def replace(old,new):
        nonlocal s
        assert s.count(old)==1,(old[:95],s.count(old))
        s=s.replace(old,new)
    replace("import 'dart:async';","import 'package:flutter/foundation.dart' show ValueListenable, mapEquals;\nimport 'package:http/http.dart' as ga_http;\nimport 'dart:async';")
    replace('class _GAItem {',(HERE/'physical.part').read_text()+'\nclass _GAItem {')
    replace('  List<_GAAldiRender> _aldiRenders = [];',(HERE/'state.part').read_text()+(HERE/'publix.part').read_text()+'\n  List<_GAAldiRender> _aldiRenders = [];')
    replace('  void _refreshDisplayedQuotes() {','  void _refreshDisplayedQuotes({bool scalesOnly=false}) {')
    replace('        _targetInventoryFetchedAt=DateTime.now();','        _targetInventoryFetchedAt=DateTime.now();\n        _refreshDisplayedQuotes(scalesOnly:true);')
    replace('    unawaited(_refreshDigitalIds(ids));','    unawaited(_refreshScaleIds(ids));\n    if(!scalesOnly)unawaited(_refreshDigitalIds(ids));')
    replace('        _targetCategories = [];','        _savedScales={};\n        _targetCategories = [];')
    replace('  Future<void> _openProduct(_GAItem item) async {','''  Future<void> _openProduct(_GAItem item, {double? maxScale,int? slotNumber,int? panelNumber}) async {
    if(_isTargetStore && _studio?.onSelect!=null &&
        await _selectForStudio(item,maxScale:maxScale,slotNumber:slotNumber,panelNumber:panelNumber))return;''')
    replace('''        items: _all.sublist(bay.firstIndex, bay.firstIndex + bay.count),
        onOpen: _openProduct,''','''        items: _all.sublist(bay.firstIndex, bay.firstIndex + bay.count),
        scales:_activeScales(_all.skip(bay.firstIndex).take(bay.count).map((e)=>e.id)),
        onScaleOpen:(item,maximum,index)=>_openProduct(item,maxScale:maximum,slotNumber:index+1),
        onOpen: _openProduct,''')
    replace('''            onOpen: _openProduct);''','''            onOpen:(item)=>_openProduct(item,panelNumber:scene.number,slotNumber:
                scene.slots.entries.firstWhere((e)=>e.value==item.id).key));''')
    replace('''        scene:scene,items:_byId,onOpen:_openProduct);''','''        scene:scene,items:_byId,onOpen:_openProduct,
        placement:_geometryFor(scene),scales:_activeScales(scene.slots.map((s)=>s.id)));''')
    replace('''    required this.scene,
    required this.items,
    required this.onOpen,''','''    required this.scene,
    required this.items,
    required this.onOpen,
    this.placement,this.scales=const {},''')
    replace('''  final _GAPublishedShelfScene scene;
  final Map<String, _GAItem> items;''','''  final _GAPublishedShelfScene scene;
  final _GAEditableShelf? placement;
  final Map<String,double> scales;
  final Map<String, _GAItem> items;''')
    replace('''                  photo,
                  for (final slot in scene.slots)''','''                  photo,
                  if(widget.placement!=null && widget.scales.isNotEmpty)
                    Positioned.fill(child:_GAStockOverlay(scene:scene,placement:widget.placement!,
                        scales:widget.scales,bucket:_GroceryAisleState._bucketBase)),
                  for (final slot in scene.slots)''')
    replace('''  const _GATargetDisplayPanel({super.key, required this.fixture,
      required this.items, required this.onOpen});''','''  const _GATargetDisplayPanel({super.key,required this.fixture,required this.items,
      required this.onOpen,this.scales=const {},this.onScaleOpen});
  final Map<String,double> scales;
  final void Function(_GAItem,double,int)? onScaleOpen;''')
    replace('''              apparel: apparel, onOpen: () => onOpen(items[index]))),''','''              apparel:apparel,scale:scales[items[index].id] ?? 1.0,
              onScaleOpen:onScaleOpen==null ? null : (maximum)=>onScaleOpen!(items[index],maximum,index),
              onOpen:()=>onOpen(items[index]))),''')
    replace('''      required this.apparel, required this.onOpen});
  final _GAItem item;''','''      required this.apparel, required this.onOpen,this.scale=1.0,this.onScaleOpen});
  final double scale;
  final ValueChanged<double>? onScaleOpen;
  final _GAItem item;''')
    replace('''    return Semantics(button: true, label: '${item.name}, ${_gaTargetPrice(item.price)}',
      child: GestureDetector(behavior: HitTestBehavior.opaque, onTap: onOpen,
        child: Column(children: [
          Expanded(child: Padding(
            padding: EdgeInsets.fromLTRB(floor ? 12 : 6, floor ? 24 : 10,
                floor ? 12 : 6, 0),
            child: Stack(fit: StackFit.expand, children: [''','''    final side=floor ? 12.0 : 6.0, top=floor ? 24.0 : 10.0;
    final baseW=math.max(1.0,box.maxWidth-2*side);
    final imageH=math.max(1.0,box.maxHeight-labelH-3);
    final baseH=math.max(1.0,imageH-top);
    final maximum=math.max(1.0,math.min(_gaMaxScale,math.min(box.maxWidth/baseW,imageH/baseH)));
    final factor=_gaScale(scale,maximum);
    void open(){if(onScaleOpen!=null){onScaleOpen!(maximum);}else{onOpen();}}
    return Semantics(button: true, label: '${item.name}, ${_gaTargetPrice(item.price)}',
      child: GestureDetector(behavior:HitTestBehavior.opaque,onTap:open,
        child: Column(children: [
          Expanded(child:ClipRect(child: Stack(fit: StackFit.expand, children: [''')
    replace('''              if (!apparel) Positioned(left: 10, right: 10, bottom: 1,''','''              if (!apparel) Positioned(left:side+10, right:side+10, bottom:1,''')
    replace('''              Padding(padding: const EdgeInsets.only(bottom: 3),
                child: _GATargetProductPhoto(urls: [item.img, ...item.photoAlternates],
                    cleanBackground: !apparel, protectPackaging: !floor && !apparel)),''','''              Positioned(left:(box.maxWidth-baseW*factor)/2,bottom:3,
                width:baseW*factor,height:baseH*factor,
                child:_GATargetProductPhoto(key:ValueKey('stock-photo-${item.id}'),
                  urls:[item.img,...item.photoAlternates],cleanBackground:!apparel,
                  protectPackaging:!floor && !apparel)),''')
    replace('''  const _GATargetProductPhoto({required this.urls,''','''  const _GATargetProductPhoto({super.key,required this.urls,''')
    replace('if(_isTargetStore && _studio?.onSelect!=null &&','if(_canSizeStock && _studio?.onSelect!=null &&')
    replace('if(!_isTargetStore || scope?.onSelect==null)return false;', 'if(!_canSizeStock || scope?.onSelect==null)return false;')
    replace('if(!mounted || !_isTargetStore)return;', 'if(!mounted || !_canSizeStock)return;')
    replace('    if (!mounted || !_isTargetStore || _all.isEmpty) return;', '    if (!mounted || !_canSizeStock || _all.isEmpty) return;')
    replace('      ..._cart.keys,', """      if(_publixAisle)
        for(final item in _all.skip(first*_perPanel).take(math.max(0,end-first)*_perPanel))item.id,
      ..._cart.keys,""")
    replace('    if(!scalesOnly)unawaited(_refreshDigitalIds(ids));','    if(_isTargetStore && !scalesOnly)unawaited(_refreshDigitalIds(ids));')
    replace('    if (!_isTargetStore) return;\n    _digitalTimer = Timer.periodic','    if (!_canSizeStock) return;\n    _digitalTimer = Timer.periodic')
    replace('    if (!_isTargetStore) return;\n    _digitalViewportTimer?.cancel();','    if (!_canSizeStock) return;\n    _digitalViewportTimer?.cancel();')
    replace('      if (_isTargetStore) {\n        _targetInventoryFetchedAt=DateTime.now();\n        _refreshDisplayedQuotes(scalesOnly:true);', '      if(_canSizeStock)_refreshDisplayedQuotes(scalesOnly:true);\n      if (_isTargetStore) {\n        _targetInventoryFetchedAt=DateTime.now();')
    replace('            photo,\n            _panelW,', '            _sizedStockRect(item,photo,cellW,row),\n            _panelW,')
    # Keep legacy deck, tickets, hit rectangles and retailer-specific SKUs intact.
    before=s.index('  Widget _stockedAislePanel(')
    after=s.index('  Widget _publishedShelfPanel(',before)
    part=s[before:after]
    assert part.count('onTap: () => _openProduct(item),')==1
    part=part.replace('onTap: () => _openProduct(item),','onTap: () => _openProduct(item,maxScale:_laneLimit(photo,cellW,row),slotNumber:slot+1),')
    s=s[:before]+part+s[after:]
    for name,end in [('_cannedPanel','_cannedFacings'),('_dryGoodsPanel','_dryGoodsFacings'),('_condimentsPanel','_cartThumb')]:
        a=s.index('  Widget '+name+'(')
        b=s.index('  Widget '+end+'(',a) if end!='_cartThumb' else s.index('  void ',a)
        part=s[a:b]
        assert part.count('            productRect,')==1 and part.count('onTap: () => _openProduct(item),')==2
        part=part.replace('            productRect,','            _sizedStockRect(item,productRect,cellW,row),').replace(
          'onTap: () => _openProduct(item),','onTap: () => _openProduct(item,maxScale:_laneLimit(productRect,cellW,row),slotNumber:i+1),')
        s=s[:a]+part+s[b:]
    # Fit the existing back-row images inside their recessed 84% region.
    # The old row layout overflowed by 3–11 px in these Publix departments.
    replace('width: faceW * 0.92,', 'width: _publixAisle ? math.min(faceW*.92,b.maxWidth*.84/3) : faceW*.92,')
    for index in range(2):
        anchor="width: faceW * 0.88,\n                      child: _netImg(\n                        item.img,\n                        '\u0024{item.id}-dry-back-"+str(index)+"'"
        replace(anchor,anchor.replace('faceW * 0.88','_publixAisle ? math.min(faceW*.88,b.maxWidth*.84/2) : faceW*.88'))
    return s

if __name__=='__main__':
    source=HERE.parent/'grocery-upgrade/widget/GroceryAisle_Target_Grocery_20261121.dart'
    (HERE/'GroceryAisle_Target_Studio.dart').write_text(apply(source.read_text()))
