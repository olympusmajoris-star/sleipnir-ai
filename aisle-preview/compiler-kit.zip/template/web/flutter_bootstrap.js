{{flutter_js}}
{{flutter_build_config}}
const config={canvasKitBaseUrl:new URL('./canvaskit/',document.baseURI).href,canvasKitVariant:'full'};
_flutter.loader.load({config,onEntrypointLoaded:async initializer=>{
  const cv=document.createElement('canvas');
  const gl=cv.getContext('webgl2') || cv.getContext('webgl');
  if(!gl){
    // A software SkSurface cannot draw lazy GPU-backed image textures.
    // Rasterize those decoded photos into CPU pixels before Flutter paints.
    const kit=await window.flutterCanvasKitLoaded;
    const canvas=document.createElement('canvas');
    kit.MakeLazyImageFromTextureSource=(source,info)=>{
      const width=info?.width||source.displayWidth||source.naturalWidth||source.width;
      const height=info?.height||source.displayHeight||source.naturalHeight||source.height;
      if(!width||!height)return null;
      canvas.width=width;canvas.height=height;
      const ctx=canvas.getContext('2d',{willReadFrequently:true});
      ctx.drawImage(source,0,0,width,height);
      const pixels=ctx.getImageData(0,0,width,height).data;
      const image=kit.MakeImage({width,height,colorType:kit.ColorType.RGBA_8888,alphaType:kit.AlphaType.Unpremul,
        colorSpace:kit.ColorSpace.SRGB}, new Uint8Array(pixels.buffer,pixels.byteOffset,pixels.byteLength),width*4);
      // Flutter may read this source until the last SkImage is disposed.
      if(image && typeof VideoFrame !== 'undefined' && source instanceof VideoFrame) {
        const dispose=image.delete.bind(image);
        image.delete=()=>{try{dispose();}finally{source.close();}};
      }
      return image;
    };
  }else{
    gl.getExtension('WEBGL_lose_context')?.loseContext();
  }
  const runner=await initializer.initializeEngine(config);
  await runner.runApp();
}});
