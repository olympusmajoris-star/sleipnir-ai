import 'package:supabase/supabase.dart';
class SupaFlow {
  static late SupabaseClient client;
}
