import 'dart:async';
import 'dart:convert';
import 'dart:html' as html;
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:supabase/supabase.dart';
import 'backend/supabase/supabase.dart';
import 'custom_code/widgets/grocery_aisle.dart';
import 'public_config.dart';
import 'flutter_flow/flutter_flow_util.dart';

const sourceSha = String.fromEnvironment('AISLE_SOURCE_SHA');
const artifactFlavor = String.fromEnvironment('AISLE_FLAVOR');
const target = '35ef70d0-3d20-4599-96a3-648ee3c7c340';
final productFormat = RegExp(r'^[a-f0-9]{8}(-[a-f0-9]{4}){3}-[a-f0-9]{12}$');

class _CatalogClient extends http.BaseClient {
  final http.Client transport = http.Client();
  @override
  Future<http.StreamedResponse> send(http.BaseRequest req) {
    final project = Uri.parse(supabaseUrl);
    final sameProject = req.url.scheme == 'https' && req.url.host == project.host;
    const allowedTables={
      '/rest/v1/stores','/rest/v1/products','/rest/v1/retail_product_presentations',
      '/rest/v1/target_render_slots','/rest/v1/target_renders','/rest/v1/aisle_renders',
      '/rest/v1/aisle_slots','/rest/v1/studio_grocery_product_scales','/rest/v1/product_sizes',
    };
    final safeRead = ['GET','HEAD'].contains(req.method) && allowedTables.contains(req.url.path);
    final categoryList = req.url.path == '/rest/v1/rpc/target_catalog_categories' && req.method == 'POST';
    if (!sameProject || (!safeRead && !categoryList)) {
      return Future.error(StateError('The preview supports catalog reads only.'));
    }
    return transport.send(req);
  }
}
void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SupaFlow.client=SupabaseClient(supabaseUrl,supabaseKey,httpClient:_CatalogClient());
  runApp(MaterialApp(debugShowCheckedModeBanner:false,home:const Scaffold(body:_Preview()),routes:{
    'Cart':(_)=>Scaffold(appBar:AppBar(title:const Text('Cart')),body:ListView(children:[
      for(final row in FFAppState().cart.whereType<Map>())ListTile(
        title:Text('${row['display_name']??row['name']??''}'),subtitle:Text('Quantity ${row['qty']??1}'),
        trailing:Text(row['price'] is num ? '\$${(row['price'] as num).toStringAsFixed(2)}':'Price pending')),
    ])),
  }));
}
class _Preview extends StatefulWidget {
  const _Preview();
  @override State<_Preview> createState()=>_PreviewState();
}
class _PreviewState extends State<_Preview> {
  final _scales=ValueNotifier<Map<String,double>>({});
  final _key=GlobalKey();
  bool _editing=true;
  final String _store=Uri.base.queryParameters['store']??target;
  late final String _initial=(Uri.base.queryParameters['aisle']??(_store==target?'Canned Goods & Soups':'Snacks')).trim();
  bool _available=false;
  String _failure='';
  Future<void> _loadStore() async {
    try {
      if(!productFormat.hasMatch(_store)) throw const FormatException();
      if(_store!=target && _store!='189581c9-d728-4e5d-9e02-ae4de19a15af') {
        final rows=await SupaFlow.client.from('stores').select('id').eq('id',_store).limit(1)
            .timeout(const Duration(seconds:12));
        if(rows.isEmpty)throw const FormatException();
      }
      if(!mounted)return;
      setState(()=>_available=true);
      WidgetsBinding.instance.addPostFrameCallback((_)=>_emit({
        'type':'ready','sourceSha256':sourceSha,'buildFlavor':artifactFlavor,'store_id':_store,
        'capabilities':['select','scale','set-aisle','move','search','focus-product'],
      }));
    } catch(_) {
      if(!mounted)return;
      setState(()=>_failure='This store is unavailable in the public grocery catalog.');
      _emit({'type':'error','sourceSha256':sourceSha,'store_id':_store,'message':_failure});
    }
  }
  late final StreamSubscription<html.Event> _subscription;
  void _emit(Map<String,dynamic> data) {
    html.document.dispatchEvent(html.CustomEvent('sleipnir-preview-up',detail:jsonEncode(data)));
  }
  @override void initState() {
    super.initState();
    _subscription=html.document.on['sleipnir-preview-down'].listen(_receive);
    _loadStore();
  }
  void _receive(html.Event event) {
    if(event is! html.CustomEvent || !mounted) return;
    final dynamic payload;
    try { payload=jsonDecode(event.detail as String); } catch (_) { return; }
    if(payload is! Map) return;
    final type=payload['type'];
    if(type=='set-mode') {
      if(payload['mode']=='shop'||payload['mode']=='select') setState(()=>_editing=payload['mode']=='select');
    } else if(type=='set-scale'||type=='sync') {
      final update=type=='sync'?payload['scales']:{payload['product_id']:payload['scale']};
      if(update is! Map || update.length>30000) return;
      final next=type=='sync'? <String,double>{} : Map<String,double>.of(_scales.value);
      for(final e in update.entries) {
        if(e.key is! String||!productFormat.hasMatch(e.key))continue;
        final value=e.value;
        if(value is num && value.isFinite && value>0 && value<=10)next[e.key]=value.toDouble();
        else if(value==null)next.remove(e.key);
      }
      _scales.value=next;
    } else if(type=='set-aisle'||type=='move'||type=='search'||type=='focus-product') {
      final arg=payload[{'set-aisle':'aisle','move':'direction','search':'query','focus-product':'product_id'}[type]];
      if(arg is String)aislePreviewNavigate(_key,type,arg);
    }
  }
  @override void dispose(){ _subscription.cancel();_scales.dispose();super.dispose(); }
  @override Widget build(BuildContext context) => _failure.isNotEmpty?Center(child:Text(_failure)):
    !_available?const Center(child:CircularProgressIndicator()):GroceryAisleStudioScope(
    scales:_scales,onSelect:_editing ? (data) => _emit({...data,'type':'select','image_url':aislePreviewImage(_key,'${data['product_id']}')}) : null,
    child:GroceryAisle(key:_key,storeId:_store,startCategory:_initial));
}
