import 'dart:async';
import 'dart:convert';
import 'dart:html' as html;
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:supabase/supabase.dart';
import 'backend/supabase/supabase.dart';
import 'custom_code/widgets/grocery_aisle.dart';
import 'public_config.dart';
import 'picker_scope.dart';
import 'flutter_flow/flutter_flow_util.dart';

const sourceSha = String.fromEnvironment('AISLE_SOURCE_SHA');
const artifactFlavor = String.fromEnvironment('AISLE_FLAVOR');
const target = '35ef70d0-3d20-4599-96a3-648ee3c7c340';
final productFormat = RegExp(r'^[a-f0-9]{8}(-[a-f0-9]{4}){3}-[a-f0-9]{12}$');

const publix = '189581c9-d728-4e5d-9e02-ae4de19a15af';
const aldi = 'e5a01340-424a-4a41-b0e6-99cb9e944733';
const dollarGeneral = '0600cb61-45f9-402b-a209-134abdaef10f';

String get _requestedStore => (Uri.base.queryParameters['store'] ?? target).trim().toLowerCase();

bool _isDollarGeneral(Map row) {
  final name = (row['name'] ?? '').toString().trim().toLowerCase();
  return row['id'] == dollarGeneral || name.contains('dollar general') || name.startsWith('dg market');
}

bool _groceryStore(Map row) {
  final category = (row['category'] ?? '').toString().trim().toLowerCase();
  final menu = (row['menu_type'] ?? '').toString().trim().toLowerCase();
  final address = (row['address'] ?? '').toString();
  final city = RegExp(r',\s*([^,]+?)\s*,\s*(?:FL|Florida)\b', caseSensitive:false).firstMatch(address)?.group(1)?.trim().replaceAll(RegExp(r'\s+'), ' ').toLowerCase();
  const shoppingMenus = {'grocery','retail','convenience','fast_food','fast_casual','sit_down'};
  return row['is_live'] == true && row['product_count'] is int && row['product_count'] > 0 && city == 'palm coast' && shoppingMenus.contains(menu) &&
      (const {target, publix, aldi}.contains(row['id']) || _isDollarGeneral(row) ||
       row['has_published_aisles'] == true || menu == 'grocery' ||
       category == 'grocery' || category == 'wholesale');
}

class _CatalogClient extends http.BaseClient {
  final http.Client transport = http.Client();

  bool _canRead(http.BaseRequest req) {
    final url = req.url, scope = 'eq.$_requestedStore';
    if (url.scheme != 'https' || url.host != Uri.parse(supabaseUrl).host) return false;
    if (req.method == 'POST') {
      if (url.path == '/rest/v1/rpc/target_catalog_categories') return _requestedStore == target;
      if (url.path != '/rest/v1/rpc/studio_product_categories' || req is! http.Request) return false;
      try {
        final body = jsonDecode(req.body);
        return body is Map && body['p_store_id'] == _requestedStore;
      } on FormatException { return false; }
    }
    if (!const {'GET','HEAD'}.contains(req.method)) return false;
    if (url.path == '/rest/v1/stores' || url.path == '/rest/v1/studio_store_summary_v') return url.queryParameters['id'] == scope;
    if (const {'/rest/v1/target_render_slots','/rest/v1/target_renders'}.contains(url.path)) {
      return _requestedStore == target;
    }
    const tables = {
      '/rest/v1/products','/rest/v1/retail_product_presentations','/rest/v1/aisle_renders',
      '/rest/v1/aisle_slots','/rest/v1/studio_grocery_product_scales','/rest/v1/product_sizes',
    };
    return tables.contains(url.path) && url.queryParameters['store_id'] == scope;
  }

  @override
  Future<http.StreamedResponse> send(http.BaseRequest req) {
    if (!_canRead(req)) {
      return Future.error(StateError('The preview supports catalog reads for the selected store only.'));
    }
    return transport.send(req);
  }

  @override
  void close() { transport.close(); super.close(); }
}
void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SupaFlow.client=SupabaseClient(supabaseUrl,supabaseKey,httpClient:_CatalogClient());
  runApp(MaterialApp(debugShowCheckedModeBanner:false,home:const Scaffold(body:_Preview()),routes:{
    'Cart':(_)=>Scaffold(appBar:AppBar(title:const Text('Cart')),body:ListView(children:[
      for(final row in FFAppState().cart.whereType<Map>())ListTile(
        title:Text('${row['display_name']??row['name']??''}'),subtitle:Text('Quantity ${row['qty']??1}'),
        trailing:Text(row['price'] is num ? '\$${(row['price'] as num).toStringAsFixed(2)}':'Price pending')),
    ])),
  }));
}
class _Preview extends StatefulWidget {
  const _Preview();
  @override State<_Preview> createState()=>_PreviewState();
}
class _PreviewState extends State<_Preview> {
  final _scales=ValueNotifier<Map<String,double>>({});
  final _key=GlobalKey();
  bool _editing=true;
  final String _store=_requestedStore;
  bool _dollarGeneral=false;
  late final String _initial=(Uri.base.queryParameters['aisle']??(_store==target?'Canned Goods & Soups':'Snacks')).trim();
  bool _available=false;
  String _failure='';
  Future<void> _loadStore() async {
    try {
      if(!studioGroceryStoreIds.contains(_store)) throw const FormatException();
      final rows=await SupaFlow.client.from('studio_store_summary_v').select('id,name,address,menu_type,category,is_live,product_count')
          .eq('id',_store).eq('is_live',true).limit(1).timeout(const Duration(seconds:12));
      if(rows.isEmpty || rows.first['id']!=_store || !_groceryStore(rows.first)) {
        throw const FormatException();
      }
      if(!mounted)return;
      setState(() { _available=true; _dollarGeneral=_isDollarGeneral(rows.first); });
      WidgetsBinding.instance.addPostFrameCallback((_)=>_emit({
        'type':'ready','sourceSha256':sourceSha,'buildFlavor':artifactFlavor,'store_id':_store,
        'capabilities':['select','scale','set-aisle','move','search','focus-product'],
      }));
    } catch(_) {
      if(!mounted)return;
      setState(()=>_failure='This store is unavailable in the public grocery catalog.');
      _emit({'type':'error','sourceSha256':sourceSha,'store_id':_store,'message':_failure});
    }
  }
  late final StreamSubscription<html.Event> _subscription;
  void _emit(Map<String,dynamic> data) {
    html.document.dispatchEvent(html.CustomEvent('sleipnir-preview-up',detail:jsonEncode(data)));
  }
  @override void initState() {
    super.initState();
    _subscription=html.document.on['sleipnir-preview-down'].listen(_receive);
    _loadStore();
  }
  void _receive(html.Event event) {
    if(event is! html.CustomEvent || !mounted) return;
    final dynamic payload;
    try { payload=jsonDecode(event.detail as String); } catch (_) { return; }
    if(payload is! Map) return;
    final type=payload['type'];
    if(type=='set-mode') {
      if(payload['mode']=='shop'||payload['mode']=='select') setState(()=>_editing=payload['mode']=='select');
    } else if(type=='set-scale'||type=='sync') {
      final update=type=='sync'?payload['scales']:{payload['product_id']:payload['scale']};
      if(update is! Map || update.length>30000) return;
      final next=type=='sync'? <String,double>{} : Map<String,double>.of(_scales.value);
      for(final e in update.entries) {
        if(e.key is! String||!productFormat.hasMatch(e.key))continue;
        final value=e.value;
        if(value is num && value.isFinite && value>0 && value<=10)next[e.key]=value.toDouble();
        else if(value==null)next.remove(e.key);
      }
      _scales.value=next;
    } else if(type=='set-aisle'||type=='move'||type=='search'||type=='focus-product') {
      final arg=payload[{'set-aisle':'aisle','move':'direction','search':'query','focus-product':'product_id'}[type]];
      if(arg is String)aislePreviewNavigate(_key,type,arg);
    }
  }
  @override void dispose(){ _subscription.cancel();_scales.dispose();super.dispose(); }
  @override Widget build(BuildContext context) => _failure.isNotEmpty?Center(child:Text(_failure)):
    !_available?const Center(child:CircularProgressIndicator()):GroceryAisleStudioScope(
    scales:_scales,onSelect:_editing ? (data) => _emit({...data,'type':'select','image_url':aislePreviewImage(_key,'${data['product_id']}')}) : null,
    child:GroceryAisle(key:_key,storeId:_store,startCategory:_initial,dollarGeneral:_dollarGeneral));
}
