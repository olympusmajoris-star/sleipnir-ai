import 'package:flutter/material.dart';
class FFAppState extends ChangeNotifier {
  static final FFAppState _shared = FFAppState._();
  factory FFAppState() => _shared;
  FFAppState._();
  List<dynamic> cart = [];
  void update(VoidCallback mutate) {mutate(); notifyListeners();}
}
extension FlutterFlowNavigation on BuildContext {
  Future<void> pushNamed(String route) async => Navigator.of(this).pushNamed(route);
}
