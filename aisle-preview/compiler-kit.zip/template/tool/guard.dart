import 'dart:io';
import 'package:analyzer/dart/analysis/utilities.dart';
import 'package:analyzer/dart/ast/ast.dart';

void main(List<String> args) {
  final text=File(args.single).readAsStringSync();
  final parsed=parseString(content:text,throwIfDiagnostics:false);
  const allowed={
    '/backend/backend.dart','/flutter_flow/ff_builtin_enums.dart','/backend/supabase/supabase.dart',
    '/flutter_flow/flutter_flow_theme.dart','/flutter_flow/flutter_flow_util.dart',
    '/custom_code/widgets/index.dart','/custom_code/actions/index.dart','/flutter_flow/custom_functions.dart',
    'dart:async','dart:collection','dart:convert','dart:math','dart:typed_data','dart:ui','dart:core',
    'package:flutter/material.dart','package:flutter/foundation.dart','package:flutter/widgets.dart',
    'package:flutter/rendering.dart','package:flutter/painting.dart','package:flutter/gestures.dart',
    'package:flutter/animation.dart','package:flutter/scheduler.dart','package:flutter/physics.dart',
    'package:http/http.dart','package:supabase/supabase.dart',
  };
  if(parsed.errors.isNotEmpty){stderr.writeln('Dart syntax error at line ${parsed.lineInfo.getLocation(parsed.errors.first.offset).lineNumber}.');exit(2);}
  for(final directive in parsed.unit.directives) {
    if(directive is ImportDirective && directive.configurations.isEmpty && allowed.contains(directive.uri.stringValue))continue;
    stderr.writeln('Unsupported dependency or directive at line ${parsed.lineInfo.getLocation(directive.offset).lineNumber}.');exit(2);
  }
}
