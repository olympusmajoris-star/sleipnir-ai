"""Compile one private, locally supplied GroceryAisle widget into a static release.

The output directory receives an allowlisted runtime. Keep --cache outside the web root.
Requires Python 3.9+, Flutter 3.38.3 with its web target, and pinned pub dependencies.
"""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile

HERE = Path(__file__).resolve().parent
ORIGINAL = '5b0c743163a3bb4350938134c36c16f745929b1bc16ef7b173bcf0c7f5182ca6'
REQUIRED = (
    'class GroceryAisle extends StatefulWidget',
    'class _GroceryAisleState extends State<GroceryAisle>',
    'class _GAItem {', 'void _switchAisle(', 'void _onSearch(',
    'void _panToContentX(', '_panelForProductIndex(', '_panelStartX(',
)
PUBLIC_FILES = (
    'index.html','frame.js','flutter_bootstrap.js','main.dart.js',
    'canvaskit/canvaskit.js','canvaskit/canvaskit.wasm',
)

def digest(path):
    with path.open('rb') as stream:
        checksum=hashlib.sha256()
        for section in iter(lambda: stream.read(1024*1024), b''):
            checksum.update(section)
        return checksum.hexdigest()

def main():
    cli=argparse.ArgumentParser(description=__doc__)
    cli.add_argument('--source',type=Path,required=True)
    cli.add_argument('--output',type=Path,required=True)
    cli.add_argument('--cache',type=Path,required=True)
    cli.add_argument('--flutter',default=shutil.which('flutter'))
    cli.add_argument('--offline',action='store_true',help='Require an already populated Flutter pub cache')
    args=cli.parse_args()
    if not args.flutter: raise ValueError('Install Flutter 3.38.3 or specify --flutter.')
    flutter=Path(args.flutter).expanduser().resolve(strict=True)
    if flutter.name not in ('flutter','flutter.bat','flutter.cmd'):raise ValueError('Expected the Flutter SDK CLI.')
    dart=flutter.with_name('cache')/'dart-sdk'/'bin'/('dart.exe' if os.name=='nt' else 'dart')
    if not dart.is_file():raise ValueError('Prepare the Flutter SDK with flutter precache --web first.')
    original=args.source.resolve(strict=True)
    if not original.is_file() or not 500<=original.stat().st_size<=5*1024*1024:raise ValueError('Expected a complete .dart widget below 5 MiB.')
    data=original.read_bytes()
    sha=hashlib.sha256(data).hexdigest()
    source=data.decode('utf-8-sig')
    if any(phrase not in source for phrase in REQUIRED):raise ValueError('Unsupported GroceryAisle source or identifier. No preview was produced.')
    cache=args.cache.resolve();output=args.output.resolve()
    if output==cache or output in cache.parents or cache in output.parents:raise ValueError('Private cache and public output must be separate directories.')
    cache.mkdir(parents=True,exist_ok=True);output.mkdir(parents=True,exist_ok=True)
    dest=output/sha
    release=dest/'release.json'
    adapter=HERE/'adapter'
    if not (adapter/'integrate.py').is_file():adapter=HERE.parent
    fingerprint=hashlib.sha256()
    for file in [Path(__file__),HERE/'navigation.dart.inc',*sorted((HERE/'template').rglob('*')),adapter/'integrate.py',*sorted(adapter.glob('*.part'))]:
        if file.is_file():fingerprint.update(file.read_bytes())
    revision=fingerprint.hexdigest()
    if release.is_file():
        meta=json.loads(release.read_text())
        if meta.get('sourceSha256')==sha and meta.get('buildSignature')==revision and meta.get('artifactSha256')==digest(dest/'main.dart.js'):
            print(json.dumps(meta));return
    run=Path(tempfile.mkdtemp(prefix='build-',dir=cache))
    staging=None
    try:
        app=run/'app'
        shutil.copytree(HERE/'template',app)
        dartfile=app/'lib/custom_code/widgets/grocery_aisle.dart'
        dartfile.write_text(source,encoding='utf-8')
        env={**os.environ,'CI':'true','FLUTTER_SUPPRESS_ANALYTICS':'true','DART_SUPPRESS_ANALYTICS':'true'}
        def call(command):
            result=subprocess.run(list(map(str,command)),cwd=app,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=300)
            if result.returncode:
                log=cache/'last-build-error.log';log.write_bytes(result.stdout)
                # Diagnostics stay in the owner's private cache. The HTTP caller only receives file and location.
                message=result.stdout.decode(errors='replace')
                brief=re.search(r'(?:Unsupported dependency or directive|Dart syntax error) at line [0-9]+\.', message)
                line=re.search(r'lib/custom_code/widgets/grocery_aisle.dart:([0-9]+):([0-9]+):',message)
                diagnostic=brief.group(0) if brief else 'Widget error at line '+line.group(1)+'.' if line else 'Private compiler diagnostics saved locally.'
                raise RuntimeError(f'{Path(command[0]).name} {command[1]} failed. {diagnostic}')
        call([flutter,'pub','get',*(['--offline'] if args.offline else [])])
        call([dart,'run','tool/guard.dart',dartfile])
        flavor='widget-with-studio-scope'
        if 'class GroceryAisleStudioScope ' not in source:
            if not (adapter/'integrate.py').is_file():raise ValueError('This upload needs a matching GroceryAisle Studio adapter.')
            module_spec=importlib.util.spec_from_file_location('grocery_aisle_known_adapter',adapter/'integrate.py')
            module=importlib.util.module_from_spec(module_spec);module_spec.loader.exec_module(module)
            try: source=module.apply(source)
            except (ValueError,AssertionError,IndexError,KeyError):raise ValueError('This widget revision needs updated shelf editing hooks. No substitute preview was produced.')
            flavor='original-with-studio-adapter' if sha==ORIGINAL else 'uploaded-with-studio-adapter'
        dartfile.write_text(source+'\n'+(HERE/'navigation.dart.inc').read_text(),encoding='utf-8')
        call([flutter,'build','web','--release','--no-pub','--no-wasm-dry-run','--no-source-maps','--csp','--no-web-resources-cdn',
              '--pwa-strategy=none','--dart-define=AISLE_SOURCE_SHA='+sha,'--dart-define=AISLE_FLAVOR='+flavor])
        built=app/'build/web'
        staging=Path(tempfile.mkdtemp(prefix='.release-',dir=output))
        for name in PUBLIC_FILES:
            target=staging/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(built/name,target)
        for file in (built/'assets').rglob('*'):
            if file.is_file() and (file.name=='NOTICES' or file.suffix.lower() in ('.bin','.json','.otf','.ttf','.z','.frag')):
                target=staging/file.relative_to(built)
                target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(file,target)
        for f in staging.rglob('*.js'):
            contents=f.read_bytes()
            contents=re.sub(rb'(?m)^//[#@]\s*sourceMappingURL=[^\r\n]+[\r\n]*',b'',contents)
            f.write_bytes(contents)
        metadata={'sourceSha256':sha,'artifactSha256':digest(staging/'main.dart.js'),'path':sha+'/index.html',
                  'buildSignature':revision,'buildFlavor':flavor,'filename':original.name,
                  'capabilities':['select','scale','set-aisle','move','search','focus-product']}
        (staging/'release.json').write_text(json.dumps(metadata,indent=2)+'\n')
        if dest.exists():
            if not release.is_file() or json.loads(release.read_text()).get('sourceSha256')!=sha:
                raise ValueError('Existing output is not a managed release.')
            old=run/'old-release'
            try:dest.rename(old)
            except OSError:
                old=Path(tempfile.mkdtemp(prefix='.superseded-',dir=output));old.rmdir();dest.rename(old)
            try:staging.rename(dest)
            except BaseException:old.rename(dest);raise
            shutil.rmtree(old)
        else:staging.rename(dest)
        print(json.dumps(metadata))
    finally:
        shutil.rmtree(run,ignore_errors=True)
        if staging and staging.exists():shutil.rmtree(staging,ignore_errors=True)

if __name__=='__main__':
    try:main()
    except Exception as exc:print(str(exc),file=sys.stderr);sys.exit(1)
