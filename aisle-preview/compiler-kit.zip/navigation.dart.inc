
// Compiled exclusively by the isolated Studio preview host.
void aislePreviewNavigate(GlobalKey stateKey, String type, String argument) {
  final state = stateKey.currentState;
  if (state is! _GroceryAisleState || !state.mounted) return;
  if (type == 'set-aisle') {
    if (argument.isNotEmpty && argument.length <= 128) state._switchAisle(argument);
  } else if (type == 'move') {
    if (state._panelCount <= 0 || (argument != 'left' && argument != 'right')) return;
    final page = (state._centerPanel + (argument == 'right' ? 1 : -1)).clamp(0, state._panelCount-1).toInt();
    state._panToContentX(state._panelStartX(page));
  } else if (type == 'search') {
    if (argument.length > 160) return;
    state._searchCtl.text = argument;
    state._onSearch(argument);
  } else if (type == 'focus-product') {
    final i = state._all.indexWhere((item) => item.id == argument);
    if (i >= 0) {
      state._panToContentX(state._panelStartX(state._panelForProductIndex(i)));
      state._openProduct(state._all[i]);
    }
  }
}

String aislePreviewImage(GlobalKey key, String productId) {
  final state=key.currentState;
  return state is _GroceryAisleState ? state._byId[productId]?.img ?? '' : '';
}
